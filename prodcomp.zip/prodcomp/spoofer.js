
window.onbeforeunload = function(){};
window.onunload = function(){};
window.alert=function(){};

