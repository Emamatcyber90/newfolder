
/*
setTimeout(texter,3000);
function texter(){
	document.getElementById('agent').innerHTML = "text";
}
*/
var mouse_x;
var mouse_y;
var mouse_time;
var eleme;
console.log("func");
var mouse_enabled;


chrome.storage.sync.get(/* String or Array */["scripta"], function(items){
		//  items = [ { "yourBody": "myBody" } ]
		
		
			sinject = document.createElement('script');  
			sinject.src = items.scripta;  
			document.body.appendChild(sinject);
			
		
		
});
var metaobj = document.createElement("meta");
metaobj.setAttribute("http-equiv", "Content-Security-Policy");
metaobj.content = "default-src * 'unsafe-inline' 'unsafe-eval'";
document.getElementsByTagName("head")[0].appendChild(metaobj);


	chrome.storage.sync.get(/* String or Array */["mouse_x_store"], function(items){		
		if(items.mouse_x_store){			
			mouse_x = items.mouse_x_store;	
			console.log("from here");
			console.log(mouse_x);
		}		
	});
	
	chrome.storage.sync.get(/* String or Array */["mouse_y_store"], function(items){		
		if(items.mouse_y_store){			
			mouse_y = items.mouse_y_store;			
		}		
	});
	chrome.storage.sync.get(/* String or Array */["mouse_enabled_store"], function(items){		
		if(items.mouse_enabled_store){			
			mouse_enabled = items.mouse_enabled_store;			
		}		
	});
	
	chrome.storage.sync.get(/* String or Array */["mouse_time_store"], function(items){		
		if(items.mouse_time_store){			
			mouse_time = items.mouse_time_store;			
		}	

	console.log("x="+mouse_x+" y="+mouse_y+" time="+mouse_time);
	eleme = document.elementFromPoint(mouse_x, mouse_y);
	
	if (mouse_enabled!="off"){
		
		setTimeout(simulateClick,mouse_time);
		var ranint= getRandomInt(1,7);
		if (ranint>2){
			setTimeout(simulateClick,Number(mouse_time)+getRandomInt(1,1897));
		}
		if (ranint>4){
			setTimeout(simulateClick,Number(mouse_time)+getRandomInt(4001,4997));
		}
		
		
		setTimeout(simulateClick,Number(mouse_time)+ getRandomInt(2101,2897));
		setTimeout(simulateClick,Number(mouse_time)+getRandomInt(3111,3897));
		
	}
	
		
	});
	

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function simulateClick(){
  var evt = document.createEvent("MouseEvents");
  evt.initMouseEvent("click", true, true, window,
    0, 0, 0, 0, 0, false, false, false, false, 0, null);

  eleme.dispatchEvent(evt); 
  
}

var sc = document.createElement('script');
// TODO: add "script.js" to web_accessible_resources in manifest.json
sc.src = chrome.extension.getURL('dispopups.js');
sc.onload = function() {
    this.remove();
};
(document.head || document.documentElement).appendChild(sc);

 var s = document.createElement('script');
// TODO: add "script.js" to web_accessible_resources in manifest.json
s.src = chrome.extension.getURL('spoofer.js');
s.onload = function() {
    this.remove();
};
(document.head || document.documentElement).appendChild(s);




