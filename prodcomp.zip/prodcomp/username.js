var username;
chrome.storage.sync.get(/* String or Array */["username"], function(items){
		//  items = [ { "yourBody": "myBody" } ]
		usernamem=items.username;
		if(items.username){
			document.getElementById('usr').value = items.username;
		}
		
});

$('#sub').click(function(){
	
	usernamef();
	
});


		
		
function usernamef(){
	username = document.getElementById('usr').value;
	document.getElementById('sub').innerHTML="<img src=\"bigb32.png\"> STARTED";
	chrome.storage.sync.set({ "username": username }, function(){
		   chrome.runtime.sendMessage({start: "getsites"});
	});

}
function updateMinutes(){
	chrome.storage.sync.get(/* String or Array */["minutes"], function(items){
		//  items = [ { "yourBody": "myBody" } ]
		
		if(items.minutes){
			
			 var secondscounter = (Number(items.minutes) * 0.7);
			var minutesearned = Math.round(secondscounter / 60);
			document.getElementById('minutes').innerHTML = minutesearned;
		}
		
	});
}
setInterval(updateMinutes,1000);