#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define GUESS_MAX 20

int main()
{
    int comp_number,user_number;
    char user_guess, computer_guess[GUESS_MAX];
    printf("This is a stone knife paper game.\n");


    printf("Please enter S (for stone) or K (for Knife) or P (for Paper).\n");
    scanf("%c",&user_guess);
    comp_number = rand() % 3;

    /*
     o = stone
     1 = kinfe
     2 = paper
    */


   if(user_guess == 'S' || user_guess == 's'){

        user_number=0;
    }
    else if(user_guess == 'K' || user_guess == 'k'){

        user_number=1;
    }
    else{

        user_number=2;
    }



    switch(comp_number){

        case 0:
            strncpy(computer_guess,"Stone (S)",GUESS_MAX);
            break;

        case 1:
            strncpy(computer_guess,"Knife (K)",GUESS_MAX);
            break;

        case 2:
            strncpy(computer_guess,"Paper (P)",GUESS_MAX);
            break;
        }

    printf("The computer guessed %s \n",computer_guess);
    if (user_number==comp_number){
         //equal no win
         printf("The game is a draw.No one wins.\n");

    }else if((user_number==0 && comp_number==1) || (user_number==1 && comp_number==2) || (user_number==2 && comp_number==1)){
        //user win

        printf("You have won.The computer lost.\n");

    }else{
        //computer win

        printf("You have lost.The computer won.\n");

    }


    return 0;
}
