#include <stdio.h>
#include <stdlib.h>

//prototypes
void add_mat(int[][3] , int[][3],int[][3]);
void read(int [][3]);

int main()
{

    int i,j,matrix_1[2][3],matrix_2[2][3],matrix_sum[2][3];

        printf("Please enter the elements of the first matrix.\n");
        read(matrix_1);

        printf("Please enter the elements of the second matrix.\n");
        read(matrix_2);


        printf("The sum is \n");
        add_mat(matrix_1,matrix_2,matrix_sum);

        //loop to print the final matix.
        for(i =0;i<2;i++){
                for(j=0;j<3;j++){
                     printf("%d \t",matrix_sum[i][j]);
                }
                printf("\n");
         }

    return 0;
}

void read(int matrix[][3]){
    //function to read the values of the matrices.
    int rows,cols;

     for (rows = 0; rows < 2 ; rows++) {
          for (cols = 0 ; cols < 3; cols++) {
             printf("Enter the elemet in row %d and column %d \n",rows+1,cols+1);
             scanf("%d", &matrix[rows][cols]);
          }
     }



}


void add_mat(int mat1[][3] , int mat2[][3],int mat_sum[][3]){
    //function to add the matrices.
    int rows,cols;

    for (rows = 0; rows < 2 ; rows++) {

          for (cols = 0 ; cols < 3; cols++) {
             mat_sum[rows][cols] = mat1[rows][cols] + mat2[rows][cols];

          }

   }


}

