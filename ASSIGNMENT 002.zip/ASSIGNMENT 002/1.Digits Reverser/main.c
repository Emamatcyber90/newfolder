#include <stdio.h>
#include <stdlib.h>



int main()
{
    int number , original , reverse = 0 ;
    printf("Please input a number.\n");
    scanf("%d",&number);
    original = number;

    while(number!=0){
        reverse = reverse * 10;
        reverse = reverse +number%10;
        number = number / 10;

    }

    printf("The reversed digits of the number are ");
    while(original%10==0){
            //if orginal number had zero(s) at the end they will be printed at the beginning.
            printf("0");
            original = original/10;

    }

    printf("%d",reverse);
    return 0;
}
