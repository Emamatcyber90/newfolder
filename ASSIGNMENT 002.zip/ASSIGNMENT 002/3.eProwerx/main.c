#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x ,n, i ;
    double factorial=1,exp =1;
    printf("This is a calculator for e^x.\nEnter value of x : ");
    scanf ("%d",&x);
    printf("Enter number of terms (n) : ");
    scanf ("%d",&n);

    for(i=1;i<=n;i++){

        factorial*= i;
        exp+= (pow(x,i)) /factorial;
    }
    printf("The answer is %f",exp);

    return 0;
}
